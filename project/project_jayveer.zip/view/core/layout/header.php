<?php Ccc::getBlock('Core_Layout_Menu')->toHtml();
	  Ccc::getBlock('Core_Layout_Message')->toHtml();  ?>